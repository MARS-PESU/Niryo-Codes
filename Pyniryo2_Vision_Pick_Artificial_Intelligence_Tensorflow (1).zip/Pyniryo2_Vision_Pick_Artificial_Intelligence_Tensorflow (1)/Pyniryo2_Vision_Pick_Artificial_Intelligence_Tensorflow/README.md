# Application exemples: Vision pick artificial intelligence tensorflow

The code of this folder is up to date. However you can still check the online documentation to get start once your application launch.
Documentation is available [here](https://docs.niryo.com/applications/ned/v1.0.4/en/source/examples/vision_pick_artificial_intelligence_tensorflow.html).



To RUN the code please run robot_gui.py

CHANGES TO MAKE : 
PLEASE make sure you change the variable accordingly to you own settings on the robot_gui.py. You will need a vision workspace to do this example.

To add an object go in LABELLING then choose any object and put the name you want.By renaming it will automatically create a new object.Then follow the steps on the tutorial.

The logo for the objects will be created automatically.